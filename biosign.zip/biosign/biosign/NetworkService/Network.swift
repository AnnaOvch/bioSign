//
//  Network.swift
//  phApp
//
//  Created by Анна on 11.05.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit
import Alamofire

enum API {
    static let url = "https://morning-citadel-78271.herokuapp.com/api/v1/"
    static func withPath(path:String)->String {
       let result =  API.url + path
       return result
    }
    
}

class Network {
    private init() {}
    static let shared = Network()
    
    func signIn(user: User,completion: @escaping (Result<Token,APIError>) -> Void) {
        guard let username = user.username else {return}
        guard let password = user.password else {return}
        AF.request(API.withPath(path: "signin/"),method: .post,parameters: ["username":username,"password":password],encoding: JSONEncoding.default).validate(statusCode: 200..<201).responseData { (response) in
            switch response.result {
            case .success(let signInModelData):
                do {
                    let tokenModel = try JSONDecoder().decode(Token.self, from: signInModelData)
                    DispatchQueue.main.async {
                        completion(.success(tokenModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInSignIn))
                }
            case .failure(_):
                if let httpStatusCode = response.response?.statusCode {
                    switch httpStatusCode {
                    case 401:
                        completion(.failure(APIError.noSuchUser))
                    default:
                        completion(.failure(APIError.badRequest))
                    }
                }
            }
        }
    }
    
    func getUser(token: String, completion: @escaping(Result<User,APIError>)->Void) {
        let headers: HTTPHeaders = ["Authorization": "Bearer \(token)"]
        AF.request(API.withPath(path: "user/current/"),method: .get, headers: headers).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let userData):
                do {
                    let userModel = try JSONDecoder().decode(User.self, from: userData)
                    Constants.mainUser = userModel
                    DispatchQueue.main.async {
                        completion(.success(userModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInGettingUser))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
                
            }
        }
    }
    
    func changeEmail(email: String, completion: @escaping(Result<User,APIError>)->Void) {
        guard let mainUser = Constants.mainUser else {return}
        guard let idUser = mainUser.id else {return}
        AF.request(API.withPath(path: "user/\(idUser)/"),method: .patch,parameters:["email":email], encoding: JSONEncoding.default).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let userData):
                do {
                    let userModel = try JSONDecoder().decode(User.self, from: userData)
                    Constants.mainUser = userModel
                    Constants.globalToken = userModel.token
                    DispatchQueue.main.async {
                        completion(.success(userModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInChangingUser))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
            }
        }
    }
    func changeUsername(username: String,completion: @escaping(Result<User,APIError>)->Void) {
        guard let mainUser = Constants.mainUser else {return}
        guard let idUser = mainUser.id else {return}
        AF.request(API.withPath(path: "user/\(idUser)/"),method: .patch,parameters:["username":username], encoding: JSONEncoding.default).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let userData):
                do {
                    let userModel = try JSONDecoder().decode(User.self, from: userData)
                    Constants.mainUser = userModel
                    Constants.globalToken = userModel.token
                    DispatchQueue.main.async {
                        completion(.success(userModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInChangingUser))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
                
            }
        }
    }
    
    func changePassword(password: String, completion: @escaping(Result<User,APIError>)->Void) {
        guard let mainUser = Constants.mainUser else {return}
        guard let idUser = mainUser.id else {return}
        AF.request(API.withPath(path: "user/\(idUser)/"),method: .patch,parameters:["password":password], encoding: JSONEncoding.default).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let userData):
                do {
                    let userModel = try JSONDecoder().decode(User.self, from: userData)
                    Constants.globalToken = userModel.token
                    Constants.password = password
                    DispatchQueue.main.async {
                        completion(.success(userModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInChangingPassword))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
            }
        }
    }
    
    func signUp(user:User,completion: @escaping(Result<User,APIError>)->Void) {
        guard let password = user.password else {return}
        guard let username = user.username else {return}
        guard let email = user.email else {return}
        
        AF.request(API.withPath(path: "signup/"),method: .post,parameters: ["username":username,"password":password,"email":email],encoding: JSONEncoding.default).validate(statusCode: 200...201).responseData { (response) in
            switch response.result {
            case .success(let userData):
                do {
                    let userModel = try JSONDecoder().decode(User.self, from: userData)
                    DispatchQueue.main.async {
                        completion(.success(userModel))
                    }
                } catch  {
                    completion(.failure(APIError.errorInSignUp))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
                
            }
        }
    }
    
    func commentCreate(textComment: String,completion: @escaping(Result<Comment,APIError>)->Void) {
       
        guard let mainUser = Constants.mainUser else {return}
               guard let idUser = mainUser.id else {return}
        AF.request(API.withPath(path: "comment/create/"),method: .post,parameters: ["text":textComment,"client":idUser],encoding: JSONEncoding.default).validate(statusCode: 200...201).responseData { response in
            switch response.result {
            case .success(let commentData):
                print("commentData")
                do {
                    let comment = try JSONDecoder().decode(Comment.self, from: commentData)
                    completion(.success(comment))
                } catch  {
                    completion(.failure(APIError.failCreateComment))
                }
            case .failure(_):
                print("commentData fail ")
                completion(.failure(APIError.badRequest))
            }
            
        }
    }
    
    func getComments(completion: @escaping(Result<[Comment],APIError>)->Void) {
        AF.request(API.withPath(path: "comment/list/"), method: .get).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let commentsData):
                do {
                    let commentsArr =  try JSONDecoder().decode([Comment].self, from: commentsData)
//                    var resultArray = [Comment]()
//                    for comment in commentsArr {
//                        self.getUsername(id: comment.client, comment: comment) { (comment) in
//                            resultArray.append(comment)
//                            print("result array \(resultArray)")
//                        }
//                    }
                    completion(.success(commentsArr))
                } catch  {
                    completion(.failure(APIError.failInGettingComments))
                }
                
            case .failure(_):
                completion(.failure(APIError.badRequest))
            }
        }
    }
    
    func getUsername(id:Int,comment:Comment, completion: @escaping (Result<Comment,APIError>)->Void){
        var comment = comment
        guard let mainUser = Constants.mainUser else {return}
       let idUser = id
        AF.request(API.withPath(path: "user/\(idUser)")).validate(statusCode: 200...201).responseData { (response) in
            switch response.result {
            case .success(let usernameData) :
                guard let usernameObj = try? JSONSerialization.jsonObject(with: usernameData, options: .allowFragments) as? [String:Any] else {return}
                guard let username = usernameObj["username"] as? String else {return}
                comment.clientUsername = username
                print(  "username - \(username)")
                completion(.success(comment))
            case .failure(let error):
                completion(.failure(APIError.failInGettingComments))
            }
        }
    }
    
    func getDocuments(completion: @escaping(Result<[Document],APIError>)->Void) {
        print("innnnnn")
        print(API.withPath(path: "document/list/"))
        print("innnnnn")
        AF.request(API.withPath(path: "document/list/"), method: .get).validate(statusCode: 200..<201).responseData { response in
            API.withPath(path: "document/list/")
            switch response.result {
            case .success(let commentsData):
                do {
                    let documentArr =  try! JSONDecoder().decode([Document].self, from: commentsData)
                    print(documentArr)
                    completion(.success(documentArr))
                } catch  {
                    completion(.failure(APIError.failInGettingDocuments))
                }
            case .failure(_):
                completion(.failure(APIError.badRequest))
            }
        }
    }
    
//    func createDocument(file: String,completion: @escaping(Result<Document,APIError>)->Void) {
//        guard let idUser = Constants.mainUser?.id as? String else {return}
//        AF.request(API.withPath(path: "document/create/"),method: .post,parameters: ["file":file,"client":idUser],encoding: JSONEncoding.default).validate(statusCode: 200...201).responseData { response in
//            switch response.result {
//            case .success(let )
//            }
//
//        }
//    }
    
    
    
}



enum APIError:Error {
    case noInternet
    case badRequest
    case noSuchUser
    case userAlreadyExists
    case errorIsUnknown
    case errorInSignIn
    case errorInSignUp
    case errorInGettingUser
    case failCreateComment
    case failInGettingComments
    case failCreateDocument
    case failInGettingDocuments
    case errorInChangingUser
    case errorInChangingPassword
    var description:String {
        switch self {
        case .noInternet:
            return "No internet connection"
        case .badRequest:
            return "Sorry bad request, server does not work "
        case .noSuchUser:
            return "No such registered user"
        case .userAlreadyExists:
            return "Suck user already exists"
        case .errorIsUnknown:
            return "Unknown error occured"
        case .errorInSignIn:
            return "Error in sign in occured"
        case .errorInSignUp:
            return "Error in sign up occured"
        case .errorInGettingUser:
            return "Error in getting user"
        case .failCreateComment:
            return "Error in creating comment"
        case .failInGettingComments:
            return "Error in getting comments"
        case .failCreateDocument:
            return "Error in creating document"
        case .failInGettingDocuments:
             return "Error in getting documents"
        case .errorInChangingUser:
            return "Error in changing user occured"
        case .errorInChangingPassword:
            return "Error in changing password occured"
        default:
            break
        }
    }
}
