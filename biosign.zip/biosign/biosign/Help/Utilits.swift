//
//  Utilits.swift
//  phApp
//
//  Created by Анна on 11.05.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit
extension UIViewController {
    
func showAlert(alertText : String, alertAction : String?, handler:((UIAlertAction) -> Void)?) {
        var completion: ((UIAlertAction) -> Void)? = nil
    
        if let handler = handler {
            completion = handler
        }
        let alert = UIAlertController(title: alertText, message: nil, preferredStyle: .alert)
        if let action = alertAction {
            alert.addAction(UIAlertAction(title: action, style: .default, handler: completion))
        }
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    func showActivityIndicatory(actView:UIActivityIndicatorView) {
         for subview in view.subviews where !(view is UIActivityIndicatorView) {
             subview.isHidden = true
         }
          actView.center = self.view.center
          actView.startAnimating()
          self.view.addSubview(actView)
      }
    func hideActivityIndicator(actView:UIActivityIndicatorView) {
          for subview in view.subviews where !(view is UIActivityIndicatorView) {
              subview.isHidden = false
          }
          actView.isHidden = true
          actView.stopAnimating()
          
      }
    
    func dismissKey()
    {
    let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard()
    {
    view.endEditing(true)
    }


}

protocol Validatings {
    func validateEmail(candidate: String) -> Bool
    func validatePassword(candidate: String) -> Bool
}
extension Validatings {
     func validateEmail(candidate: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
           return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: candidate)
       }
       func validatePassword(candidate: String) -> Bool {
           let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,}$"
           
           return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: candidate)
           
       }
    
    func validateName(candidate: String)->Bool {
        if candidate.isEmpty || candidate.count==1 {
            return false
        }
        return true
    }
}


