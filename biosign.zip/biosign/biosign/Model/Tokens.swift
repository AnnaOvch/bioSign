//
//  Tokens.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import Foundation

struct Token: Codable {
    let access: String
}
