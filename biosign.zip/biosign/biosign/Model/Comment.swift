//
//  Comment.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import Foundation
struct Comment: Codable {
    var text: String
    var client: Int
    var clientUsername: String?
    init() {
        self.text = ""
        self.client = 0 
    }
}
struct CommentArray: Codable {
    var comments: [Comment]
}
