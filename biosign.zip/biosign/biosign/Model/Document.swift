//
//  Document.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import Foundation
struct Document: Codable {
    let id: Int
    let file: String
    let sign: Bool
    let client_from: Int
    //let  client_to: Int?
}
struct DocumentArray: Codable {
    let documents: [Document]
}
struct DocumentFile: Codable {
    let file: String
}
