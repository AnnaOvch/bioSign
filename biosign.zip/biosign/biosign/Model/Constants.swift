//
//  Constants.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import Foundation
enum Constants {

    static var globalToken: String?
    static var mainUser: User?
    static var password: String?
}
