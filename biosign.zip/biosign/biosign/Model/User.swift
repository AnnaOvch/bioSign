
import Foundation

struct User: Codable {
    var email: String?
    var username: String?
    var id: Int?
    var password: String?
    var token: String?
}

