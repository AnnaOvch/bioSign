//
//  AddCommentViewController.swift
//  biosign
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class AddCommentViewController: UIViewController {

    @IBOutlet weak var commentTextView: UITextView!
    
    var completion: ((String)->Void)?
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dismissKeyboard()
        commentTextView.delegate = self
        commentTextView.text = "Placeholder text goes right here..."
        commentTextView.textColor = UIColor.lightGray

        // Do any additional setup after loading the view.
    }
    @IBAction func saveButtonTapped(_ sender: Any) {
        if commentTextView.text.isEmpty == true {
            self.showAlert(alertText: "Enter your comment", alertAction: "ok", handler: nil)
        } else {
            print("save is not empty")
            let comment = commentTextView.text!
            //showActivityIndicatory(actView: activityView)
            Network.shared.commentCreate(textComment: comment) { [weak self](result) in
                switch result {
                case .success(let comment):
                    self?.showAlert(alertText: "Thenks for comment, it is under review", alertAction: "ok") { (action) in
                        self?.navigationController?.popViewController(animated: true)
                    }
                case .failure(let error):
                    //self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                }
            }
        }
    }
    

}
extension AddCommentViewController: UITextViewDelegate {

    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text as NSString).rangeOfCharacter(from: CharacterSet.newlines).location == NSNotFound {
            return true
        }
        textView.resignFirstResponder()
        return false
    }
    func textViewDidBeginEditing(_ textView: UITextView) {

        if textView.textColor == UIColor.lightGray {
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    
    
}
