//
//  CommentCollectionViewCell.swift
//  biosign
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class CommentCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var usernamelabel: UILabel!
    @IBOutlet weak var commentTextLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func setUpLabels(username:String?, comment: String?) {
        
        self.usernamelabel.text = username ?? ""
        self.commentTextLabel.text = comment ?? ""
    }

}
