//
//  CommentsCollectionViewController.swift
//  biosign
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class CommentsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    var commentItems: [Comment]?
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    var refreshControl = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        downloadComments()
        self.navigationItem.title = "Comments"
        self.collectionView!.register(UINib(nibName: "CommentCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
        
         refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        collectionView.refreshControl = refreshControl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
         downloadComments()
    }
    
    @objc func refresh(_ sender: AnyObject) {
        self.collectionView.reloadData()
        downloadComments()
        self.refreshControl.endRefreshing()
    }


    // MARK: UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //let insets: CGFloat = 10.0
       // let insets = UIEdgeInsets(top: 7, left: 10, bottom: 10, right: 10)
        let ins: CGFloat = 10.0
        let width: CGFloat = collectionView.bounds.width - 2 * ins
        let height: CGFloat = 119.0

        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: self.view.frame.width, height: 10)
        }
        return CGSize(width: 0, height: 0)
    }
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let items = commentItems?.count {
            return items
        } else {
            return 0
        }
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CommentCollectionViewCell
        let comment = commentItems?[indexPath.item]
        cell.setUpLabels(username: comment?.clientUsername, comment: comment?.text)
    
    
        return cell
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc =  segue.destination  as! AddCommentViewController

    }

}

extension CommentsCollectionViewController {
    func downloadComments() {
       // showActivityIndicatory(actView: activityView)
        Network.shared.getComments { [weak self](result) in
            switch result {
            case .success(let comments):
                var resultArray = [Comment]()
                let concurrentQueue = DispatchQueue(label: "queue", attributes: .concurrent)
                let myGroup = DispatchGroup()
                
                for comment in comments {
                    myGroup.enter()
                    Network.shared.getUsername(id: comment.client, comment: comment) { (result) in
                        switch result {
                        case .success(let comment):
                        //    self?.hideActivityIndicator(actView: self!.activityView)
                            print("append \(comment)")
                            resultArray.append(comment)
                        case .failure(let error):
                           // self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                        myGroup.leave()
                    }
                }
                myGroup.notify(queue: DispatchQueue.main) {
                    print("comment items \(resultArray)")
                    self?.commentItems = resultArray
                    self?.collectionView.reloadData()
                }
            case .failure(let error):
               // self?.hideActivityIndicator(actView: self!.activityView)
                self?.commentItems = nil
                self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
            }
        }
    }
    
    
}
