//
//  SignUpViewController.swift
//  phApp
//
//  Created by Анна on 11.05.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController,Validatings {

    @IBOutlet weak var email: TextFieldCustom!
    @IBOutlet weak var password: TextFieldCustom!
    @IBOutlet weak var username: TextFieldCustom!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDelegates()
        dismissKey()
        
    }
    
    @IBAction func signUpBtn(_ sender: Any) {
        if email.text?.isEmpty == true || password.text?.isEmpty == true || username.text?.isEmpty == true {
            self.showAlert(alertText: "Enter all fields please", alertAction: "ok", handler: nil)
        } else {
            let emailCheck = validateEmail(candidate: email.text!)
            let passwordCheck = validatePassword(candidate: password.text!)
            let usernameCheck = username.text?.isEmpty
            if usernameCheck == true {
                 self.showAlert(alertText: "Empty username", alertAction: "ok", handler: nil)
            } else if emailCheck == false {
                let text = "Unavailable email"
                self.showAlert(alertText: text, alertAction: "ok", handler: nil)
            }
            else if passwordCheck == false {
                let text = "Unavailable password"
                self.showAlert(alertText: text, alertAction: "ok", handler: nil)
            }
            else {
                let user =  User(email: email.text!, username: username.text!, password: password.text!)
                Network.shared.signUp(user: user) { (result) in
                    switch result {
                    case .success(let user):
                        guard let username = user.username else {return}
                        self.showAlert(alertText: "Dear \(username), you were successfully registered", alertAction: "ok") { alert in
                            self.dismiss(animated: true, completion: nil)
                        }
                    case .failure(let error):
                        self.showAlert(alertText: error.description, alertAction: "ok", handler: nil)

                    }
                }
            }
        }
    }
    
      
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension SignUpViewController: UITextFieldDelegate {
    func setUpDelegates () {
           email.delegate = self
           password.delegate = self
           username.delegate = self
       }
    
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}


