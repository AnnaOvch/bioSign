//
//  DocumentTableViewCell.swift
//  biosign
//
//  Created by Анна on 05.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class DocumentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameDocument: UILabel!
    
    @IBOutlet weak var signImage: UIImageView!
    //var name: String?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //self.nameDocument.text = name
        
    }
    func configure(name:String, isSign: Bool){
        self.nameDocument.text = name
        switch isSign {
        case true:
            self.signImage.image = UIImage.init(named: "icons8-галочка-26")
        case false:
            self.signImage.image = UIImage.init(named: "icons8-отмена-26")
            
        }
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
