//
//  ProfileTableViewController.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class ProfileTableViewController: UITableViewController {
    

    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var email: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.allowsSelection = false
        username.text = Constants.mainUser?.username
        email.text = Constants.mainUser?.email

    }
    @IBAction func logOutButton(_ sender: Any) {
        self.dismiss(animated: false) {
            Constants.globalToken = nil
            Constants.mainUser = nil
            Constants.password = nil
        }
    }
    @IBAction func changePasswordButton(_ sender: Any) {
        let vc = UIStoryboard(name: "Profile", bundle: nil).instantiateViewController(identifier: "changeId") as ChangePasswordViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    

}

extension ProfileTableViewController  {
//    func saveButtonTapped() {
//        print("save")
//    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Profile", bundle: nil).instantiateViewController(identifier: "editPtofile") as EditProfileTableViewController
        switch indexPath.section {
        case 0:
            vc.oldValue = self.username.text
             vc.titleForNav = "Editing username"
            vc.completionBlock = { [weak self] newValueText in
                self?.username.text = newValueText
            }
        case 1:
            vc.oldValue = self.email.text
            vc.titleForNav = "Editing email"
            vc.completionBlock = { [weak self] newValueText in
                self?.email.text = newValueText
            }
        default:
            break
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
       
    }
}
