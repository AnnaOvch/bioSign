//
//  ChangePasswordViewController.swift
//  biosign
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {
    
    @IBOutlet weak var oldPasswordTextField: UITextField!
    @IBOutlet weak var newPasswordTextField: UITextField!
    
     let button = UIBarButtonItem(barButtonSystemItem: .save, target: self, action:  #selector(saveButtonTap))
     let activityView = UIActivityIndicatorView(style: .medium)

    override func viewDidLoad() {
        super.viewDidLoad()
        settingForViewDidLoad()
        
    }
    func settingForViewDidLoad() {
        navigationItem.rightBarButtonItem = button
        button.isEnabled = false
       oldPasswordTextField.addTarget(self, action: #selector(saveButtonDisabledOld), for: .editingChanged)
       newPasswordTextField.addTarget(self, action: #selector(saveButtonDisabledNew), for: .editingChanged )
       navigationItem.title = "Changing password"
        oldPasswordTextField.delegate = self
        newPasswordTextField.delegate = self
        dismissKey()
    }
    
    
    @objc func saveButtonTap() {
        guard let oldPass = oldPasswordTextField.text else {return}
        guard let newPass = newPasswordTextField.text else {return}
        guard let userPass = Constants.password else {return}
        if oldPass == userPass {
            self.showActivityIndicatory(actView: activityView)
            Network.shared.changePassword(password: newPass) {[weak self] (result) in
                switch result {
                case .success(_):
                    self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: "You changed your password successfully", alertAction: "ok", handler: { (action) in
                        self?.navigationController?.popViewController(animated: true)
                    })
                case .failure(let error):
                    self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: { (action) in
                        self?.navigationController?.popViewController(animated: true)
                    })
                }
            }
        } else {
            self.showAlert(alertText: "Old password is incorrect, you can not change password", alertAction: "ok", handler: nil)
        }
    }
    
    @objc func saveButtonDisabledOld () {
        if oldPasswordTextField.text?.count == 0 {
            button.isEnabled = false
        } else {
            button.isEnabled = true
        }
    }
    @objc func saveButtonDisabledNew () {
        if newPasswordTextField.text?.count == 0 {
            button.isEnabled = false
        } else {
            button.isEnabled = true
        }
    }
    

}
extension ChangePasswordViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
