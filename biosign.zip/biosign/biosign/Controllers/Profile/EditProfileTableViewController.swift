//
//  EditProfileTableViewController.swift
//  biosign
//
//  Created by Анна on 02.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class EditProfileTableViewController: UITableViewController, Validatings {
    @IBOutlet weak var oldValueLabel: UILabel!
    @IBOutlet weak var newValueTextField: UITextField!
    
    var oldValue: String?
    
    var completionBlock: ((String)->Void)?
    
    var titleForNav: String?
    
    let button = UIBarButtonItem(barButtonSystemItem: .save, target: self, action:  #selector(saveButtonTap))
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavBar()
    }
    
    func setUpNavBar() {
        newValueTextField.delegate = self
        navigationItem.rightBarButtonItem = button
        button.isEnabled = false
        oldValueLabel.text = oldValue
        newValueTextField.addTarget(self, action: #selector(saveButtonDisabled), for: .editingChanged)
        tableView.allowsSelection = false
        self.navigationItem.title = titleForNav
        dismissKey()
    }
    
    @objc func saveButtonDisabled () {
        if newValueTextField.text?.count == 0 {
            button.isEnabled = false
        } else {
            button.isEnabled = true
        }
    }
    
    @objc func saveButtonTap() {
        guard let text = newValueTextField.text else {return}
        var checkBool: Bool?
        switch titleForNav{
        case "Editing username":
            checkBool =  self.validateName(candidate: text)
            if checkBool == false {
                self.showAlert(alertText: "Unavailable username", alertAction: "ok", handler: nil)
            } else {
                self.showActivityIndicatory(actView: activityView)
                Network.shared.changeUsername(username: text) {[weak self](result) in
                    switch result {
                    case .success(_):
                        self?.showAlert(alertText: "Your changes were committed", alertAction: "ok") { (action) in
                            self?.completionBlock?(text)
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    case .failure(let error):
                        self?.hideActivityIndicator(actView: self!.activityView)
                        self?.showAlert(alertText: error.description, alertAction: "ok") { (action) in
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                }
                
            }
        case "Editing email":
            checkBool = self.validateEmail(candidate: text)
            if checkBool == false {
                self.showAlert(alertText: "Unavailable email", alertAction: "ok", handler: nil)
            } else {
                self.showActivityIndicatory(actView: activityView)
                Network.shared.changeEmail(email: text) {[weak self] (result) in
                    switch result {
                    case .success(_):
                        self?.hideActivityIndicator(actView: self!.activityView)
                        self?.showAlert(alertText: "Your changes were committed", alertAction: "ok") { (action) in
                            self?.completionBlock?(text)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    case .failure(let error):
                        self?.hideActivityIndicator(actView: self!.activityView)
                        self?.showAlert(alertText: error.description, alertAction: "ok") { (action) in
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                }
                
            }
        default:
            break
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}

extension EditProfileTableViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
