//
//  WelcomeViewController.swift
//  phApp
//
//  Created by Анна on 11.05.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
