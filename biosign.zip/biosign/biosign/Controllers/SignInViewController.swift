//
//  SignInViewController.swift
//  phApp
//
//  Created by Анна on 11.05.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit
import Alamofire

class SignInViewController: UIViewController,Validatings {
    
    @IBOutlet weak var username: TextFieldCustom!
    
    @IBOutlet weak var password: TextFieldCustom!
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDelegates()
        dismissKey()
 }
    
    @IBAction func signInBtn(_ sender: Any) {
        if username.text?.isEmpty == true || password.text?.isEmpty == true {
            self.showAlert(alertText: "Enter all fields please", alertAction: "ok", handler: nil)
        } else {
            let user = User(username: username.text!, password: password.text!)
            self.showActivityIndicatory(actView: activityView)
            Network.shared.signIn(user: user) {[weak self] (result) in
                switch result {
                case .success(let token):
                    Constants.globalToken = token.access
                    Constants.password = user.password
                    guard let currentToken = Constants.globalToken else {return}
                    Network.shared.getUser(token: currentToken) { [weak self] (result) in
                        switch result {
                        case .success(let user):
                            Constants.mainUser = user
                            let vc = TabViewController.instance()
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.present(vc, animated: true)
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                    }
                case .failure(let error):
                    self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                }
            }
        }
    }
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension SignInViewController: UITextFieldDelegate {
    func setUpDelegates() {
        username.delegate = self
        password.delegate = self
    }
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
