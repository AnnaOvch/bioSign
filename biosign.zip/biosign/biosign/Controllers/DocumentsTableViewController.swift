//
//  DocumentsTableViewController.swift
//  biosign
//
//  Created by Анна on 05.06.2020.
//  Copyright © 2020 Анна. All rights reserved.
//

import UIKit

class DocumentsTableViewController: UITableViewController {
    
    var documentsArray:[Document]?

    override func viewDidLoad() {
        super.viewDidLoad()
        getDocuments()
        tableView.tableFooterView = UIView()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let doc = documentsArray else {
            return 0
        }
        return doc.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "docCell") as! DocumentTableViewCell
        let nameFull = documentsArray?[indexPath.row].file ?? ""
        
        if let ii = nameFull.lastIndex(of: "/"), let doc = documentsArray?[indexPath.row]
        {
            var name = nameFull.substring(from: ii)
            name.remove(at:  nameFull.startIndex)
            cell.configure(name:name,isSign:doc.sign)
        }
        
        return cell
    }

}

extension DocumentsTableViewController {
    func getDocuments() {
        Network.shared.getDocuments { [weak self](result) in
                   switch result {
                   case .success(let docArr):
                       print("success")
                       guard let user = Constants.mainUser else {return}
                       guard let id = user.id else {
                           return
                       }
                       var docArr2  = [Document]()
                       for i in docArr {
                           if i.client_from == id {
                               docArr2.append(i)
                           }
                       }
                       self?.documentsArray = docArr2
                       self?.tableView.reloadData()
                       print("reloaded")
                   case .failure(let error):
                       self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                   }
               }
               
    }
}
